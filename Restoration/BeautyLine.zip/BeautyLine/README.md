# BeautyLine

BeautyLine icon theme for Garuda Linux.

This is a fork of Beautyline by [sajjad606](https://www.opencode.net/sajjad606).
Also includes icons from [Candy icons](https://github.com/EliverLara/candy-icons) by [EliverLara](https://github.com/EliverLara).

_________________________________________________________________

BeautyLine Icon Theme is published under GPLV3 LICENSE @COPYING

Notes:
I'm available via Gmail as written in @AUTHORS, and any participation is most welcome.

Idea of this icon set is from recent line style icon sets and created up on mix of my other works to make some of my beloved OpenSource Community Enjoy, so its not a complete icon set and some of icons are restyled just to fit the line style and need to redesigned again. (Future works)

Although I published <BeautyLine Icon Theme> under GPLV3 but some of icons in pack are in online selling plans and IT WOULD BE KIND OF YOU IF YOU WOULD NOT Republish it under any other Name and MOD.

Although I try to keep theme pack updated and add most distro's common icons But feel free to add common icons of any distro and DE and publish it in any Repo and OS Under the Name <BeautyLine Icon Theme> and <Sajjad Abdollahzadeh> Author.

Enjoy it and if you have time and interest, help me to get it better ...

## Screenshots 

![](https://cdn.pling.com/img/c/8/a/4/b742be5089b7686336e31a0eab4ed0cac3c9afb7b8e79ac42b004aad1b7693abcecf.png)
